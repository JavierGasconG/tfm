import os, argparse, json, gettext
import pandas as pd
from msTools import i18n
from msTools.data_manager import DataManager
from msGait.movement_detector import MovementDetector
from datetime import datetime, timedelta

class VAction(argparse.Action):
    """
    Clase para manejar el nivel de verbose (-v).
    """
    def __call__(self, parser, namespace, values, option_string=None):
        if values is None:
            setattr(namespace, self.dest, getattr(namespace, self.dest) + 1)
        else:
            setattr(namespace, self.dest, int(values))

# Define the language
idioma_app = os.environ.get('LANG', 'es_ES') # Ejemplo: obtener del entorno
i18n.init_translation(idioma_app) # Inicializa la traducción

def main():
    #
    parser= argparse.ArgumentParser(description=i18n._("ARG_TIT_FIND_GAIT"))
    parser.add_argument("-i", "--ids", dest="act_all_ids", type=json.loads, required=True,
                        help=i18n._("ARG_LIST_ACT_ALL_IDS"))
    parser.add_argument("-c", "--config", dest="config_file", type=str, required=True,
                        help=i18n._("ARG_STR_PATH_YAML"))
    parser.add_argument("-l", "--lang", dest="lng", type=str, help=i18n._("ARG_STR_LNG"))
    parser.add_argument("-v", "--verbose", action=VAction, nargs="?", default=0, const=1,
                        help=i18n._("ARG_VB_LEVEL"))
    args  = parser.parse_args()

    # Activity_all Management.
    if len(args.lng) > 0:
        i18n.init_translation(args.lng)

    act_all_ids = args.act_all_ids
    if args.verbose >= 1:
        print(i18n._("PRCS_LIST_ACT_ALL_IDS"))

    # Cargar ventanas de actividad combinadas
    data_manager = DataManager(config_path=args.config_file)
    # Format the list into a comma-separated string for the SQL IN clause
    ids_string = ', '.join(map(str, act_all_ids))
    query = f"""
        SELECT id, start_time, end_time, duration, codeid_ids, codeleg_ids, active_legs
               FROM activity_all
               WHERE id in ({ids_string}) ORDER BY codeid_ids;
    """
    try:
        activity_all = data_manager.fetch_data(query)
    except Exception as e:
        print(f"Error al obtener ventanas de actividad: {e}")
        return

    if activity_all.empty:
        print("No se encontraron ventanas de actividad.")
        return

    df_legs = data_manager.recover_activity_all(activity_all,args.verbose)

    # Detectar marcha efectiva
    detector = MovementDetector(data_manager=data_manager,
        sampling_rate=50, params = args.config_file['movement'], 
        verbose=args.verbose)

    if args.verbose >= 1:
        print("Detectando marchas efectivas...")

    df_effective = detector.detect_effective_movement(df_legs)

    if df_effective.empty:
        print("No se detectó marcha efectiva en este rango.")
        return

    if args.verbose >= 2:
        print("Primeras marchas detectadas:")
        print(df_effective.head())

    # Guardar en base de datos
    detector.save_to_postgresql("effective_movement", df_effective)

    if args.verbose >= 1:
        print(f"Marchas efectivas guardadas: {len(df_effective)}")
        print("Proceso finalizado correctamente.")


if __name__ == "__main__":
    main()
