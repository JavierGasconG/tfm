msGait package
==============

Submodules
----------

msGait.gait\_classifier module
------------------------------

.. automodule:: msGait.gait_classifier
   :members:
   :undoc-members:
   :show-inheritance:

msGait.models module
--------------------

.. automodule:: msGait.models
   :members:
   :undoc-members:
   :show-inheritance:

msGait.movement\_detector module
--------------------------------

.. automodule:: msGait.movement_detector
   :members:
   :undoc-members:
   :show-inheritance:

msGait.trajectory\_analyzer module
----------------------------------

.. automodule:: msGait.trajectory_analyzer
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: msGait
   :members:
   :undoc-members:
   :show-inheritance:
